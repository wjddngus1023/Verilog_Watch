package com.example.final_project.ui.next_month;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.final_project.R;

public class next_monthfrag extends Fragment {

    private next_monthViewModel nextmonthViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        nextmonthViewModel =
                ViewModelProviders.of(this).get(next_monthViewModel.class);
        View root = inflater.inflate(R.layout.next_month, container, false);
        final TextView textView = root.findViewById(R.id.text_nextmonth);
        nextmonthViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }
}
package com.example.final_project.ui.this_month;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class this_monthViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public this_monthViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}